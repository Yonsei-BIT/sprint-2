(function() {
  if (window.__lns_injected) return;
  window.__lns_injected = true;

  var foundUrl = null;

  // XHR 인터셉터
  var _open = XMLHttpRequest.prototype.open;
  XMLHttpRequest.prototype.open = function(method, url) {
    if (typeof url === 'string' && url.indexOf('.m3u8') !== -1 && !foundUrl) {
      foundUrl = url;
      chrome.runtime.sendMessage({ type: 'M3U8_FOUND', url: url });
    }
    return _open.apply(this, arguments);
  };

  // fetch 인터셉터
  var _fetch = window.fetch;
  if (_fetch) {
    window.fetch = function() {
      var url = arguments[0];
      if (typeof url === 'string' && url.indexOf('.m3u8') !== -1 && !foundUrl) {
        foundUrl = url;
        chrome.runtime.sendMessage({ type: 'M3U8_FOUND', url: url });
      }
      return _fetch.apply(this, arguments);
    };
  }

  // Performance API로 이미 로드된 것 확인
  function checkPerf() {
    if (!window.performance || !window.performance.getEntriesByType) return;
    var entries = window.performance.getEntriesByType('resource');
    for (var i = 0; i < entries.length; i++) {
      if (entries[i].name && entries[i].name.indexOf('.m3u8') !== -1) {
        if (!foundUrl) {
          foundUrl = entries[i].name;
          chrome.runtime.sendMessage({ type: 'M3U8_FOUND', url: foundUrl });
        }
        return;
      }
    }
  }

  checkPerf();

  // 팝업에서 요청 오면 현재 상태 응답
  chrome.runtime.onMessage.addListener(function(msg, sender, sendResponse) {
    if (msg.type === 'GET_STATUS') {
      var dur = 0;
      var title = document.title.replace(/\s*[-|].*$/, '').trim() || '강의';
      var videos = document.querySelectorAll('video');
      for (var i = 0; i < videos.length; i++) {
        if (videos[i].duration && isFinite(videos[i].duration)) {
          dur = Math.round(videos[i].duration / 60);
          break;
        }
      }
      sendResponse({ url: foundUrl, title: title, duration: dur });
    }
    return true;
  });
})();
