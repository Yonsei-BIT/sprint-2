var m3u8Cache = {};

chrome.runtime.onMessage.addListener(function(msg, sender, sendResponse) {
  if (msg.type === 'M3U8_FOUND' && sender.tab) {
    m3u8Cache[sender.tab.id] = msg.url;
    chrome.action.setBadgeText({ text: '!', tabId: sender.tab.id });
    chrome.action.setBadgeBackgroundColor({ color: '#6ee7b7', tabId: sender.tab.id });
  }
  if (msg.type === 'GET_CACHED') {
    sendResponse({ url: m3u8Cache[msg.tabId] || null });
    return true;
  }
  if (msg.type === 'GET_ALL_CACHED') {
    // 모든 캐시에서 가장 최근 URL 반환
    var keys = Object.keys(m3u8Cache);
    if (keys.length === 0) {
      sendResponse({ url: null });
      return true;
    }
    // learnus viewer 탭 우선
    var url = null;
    var title = '강의';
    chrome.tabs.query({}, function(tabs) {
      for (var i = 0; i < tabs.length; i++) {
        var t = tabs[i];
        if (m3u8Cache[t.id]) {
          if (t.url && t.url.indexOf('viewer.php') !== -1) {
            url = m3u8Cache[t.id];
            title = t.title ? t.title.replace(/\s*[-|].*$/, '').trim() : '강의';
            break;
          }
        }
      }
      if (!url) {
        var lastKey = keys[keys.length - 1];
        url = m3u8Cache[lastKey];
      }
      sendResponse({ url: url, title: title });
    });
    return true;
  }
});

chrome.webRequest.onBeforeRequest.addListener(
  function(details) {
    if (details.tabId < 0) return;
    var url = details.url;
    if (url.indexOf('.m3u8') !== -1) {
      m3u8Cache[details.tabId] = url;
      chrome.action.setBadgeText({ text: '!', tabId: details.tabId });
      chrome.action.setBadgeBackgroundColor({ color: '#6ee7b7', tabId: details.tabId });
      return;
    }
    if (url.indexOf('.ts') !== -1 && !m3u8Cache[details.tabId]) {
      var m3u8Url = url.replace(/\/segment-[^\/]+\.ts(\?.*)?$/, '/index.m3u8');
      if (m3u8Url !== url) {
        m3u8Cache[details.tabId] = m3u8Url;
        chrome.action.setBadgeText({ text: '!', tabId: details.tabId });
        chrome.action.setBadgeBackgroundColor({ color: '#6ee7b7', tabId: details.tabId });
      }
    }
  },
  { urls: ['<all_urls>'] }
);
