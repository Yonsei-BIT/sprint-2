#!/usr/bin/env python3
import sys, json, struct, subprocess, os, tempfile, shutil

def read_message():
    raw = sys.stdin.buffer.read(4)
    if not raw: return None
    length = struct.unpack('=I', raw)[0]
    return json.loads(sys.stdin.buffer.read(length).decode('utf-8'))

def send_message(msg):
    data = json.dumps(msg, ensure_ascii=False).encode('utf-8')
    sys.stdout.buffer.write(struct.pack('=I', len(data)))
    sys.stdout.buffer.write(data)
    sys.stdout.buffer.flush()

def send_progress(message, percent=None):
    msg = {'type': 'progress', 'message': message}
    if percent is not None:
        msg['percent'] = percent
    send_message(msg)

def find_ffmpeg():
    # shutil.which로 먼저 찾기
    found = shutil.which('ffmpeg')
    if found:
        return found
    # 흔한 설치 경로들
    paths = [
        r'C:\ffmpeg\bin\ffmpeg.exe',
        r'C:\Program Files\ffmpeg\bin\ffmpeg.exe',
        r'C:\ProgramData\chocolatey\bin\ffmpeg.exe',
        os.path.expanduser(r'~\AppData\Local\Microsoft\WinGet\Packages\Gyan.FFmpeg_Microsoft.Winget.Source_8wekyb3d8bbwe\ffmpeg-8.1.1-full_build\bin\ffmpeg.exe'),
    ]
    # WinGet 설치 경로 동적 탐색
    winget_base = os.path.expanduser(r'~\AppData\Local\Microsoft\WinGet\Packages')
    if os.path.exists(winget_base):
        for folder in os.listdir(winget_base):
            if 'ffmpeg' in folder.lower() or 'FFmpeg' in folder:
                for root, dirs, files in os.walk(os.path.join(winget_base, folder)):
                    if 'ffmpeg.exe' in files:
                        return os.path.join(root, 'ffmpeg.exe')
    for p in paths:
        if os.path.exists(p):
            return p
    return None

def run_ffmpeg(ffmpeg, m3u8_url, output_path):
    send_progress('FFmpeg로 영상 다운로드 중...', 10)
    cmd = [ffmpeg, '-i', m3u8_url, '-c', 'copy', '-y', output_path]
    try:
        proc = subprocess.Popen(cmd, stderr=subprocess.PIPE, universal_newlines=True, creationflags=subprocess.CREATE_NO_WINDOW if hasattr(subprocess, 'CREATE_NO_WINDOW') else 0)
        for line in proc.stderr:
            if 'time=' in line:
                send_progress('다운로드 중... ' + line.split('time=')[1].split(' ')[0], 30)
        proc.wait()
        if proc.returncode != 0:
            return False, 'FFmpeg 다운로드 실패'
        return True, None
    except Exception as e:
        return False, str(e)

def transcribe(api_key, audio_path):
    import urllib.request
    send_progress('Whisper API로 변환 중...', 60)
    
    file_size = os.path.getsize(audio_path)
    
    # 25MB 초과시 분할
    if file_size > 24 * 1024 * 1024:
        return split_transcribe(api_key, audio_path)
    
    try:
        with open(audio_path, 'rb') as f:
            audio_data = f.read()
        
        boundary = 'lns_boundary_xyz'
        body = (
            '--' + boundary + '\r\n'
            'Content-Disposition: form-data; name="file"; filename="audio.mp4"\r\n'
            'Content-Type: audio/mp4\r\n\r\n'
        ).encode() + audio_data + (
            '\r\n--' + boundary + '\r\n'
            'Content-Disposition: form-data; name="model"\r\n\r\nwhisper-1\r\n'
            '--' + boundary + '\r\n'
            'Content-Disposition: form-data; name="language"\r\n\r\nko\r\n'
            '--' + boundary + '--\r\n'
        ).encode()
        
        req = urllib.request.Request(
            'https://api.openai.com/v1/audio/transcriptions',
            data=body,
            headers={
                'Authorization': 'Bearer ' + api_key,
                'Content-Type': 'multipart/form-data; boundary=' + boundary
            }
        )
        with urllib.request.urlopen(req, timeout=300) as r:
            result = json.loads(r.read())
            return True, result.get('text', '')
    except Exception as e:
        return False, str(e)

def split_transcribe(api_key, audio_path):
    ffmpeg = find_ffmpeg()
    if not ffmpeg:
        return False, 'FFmpeg를 찾을 수 없어요'
    
    send_progress('파일 분할 중...', 55)
    tmp_dir = tempfile.mkdtemp()
    pattern = os.path.join(tmp_dir, 'part_%03d.mp4')
    subprocess.run([ffmpeg, '-i', audio_path, '-c', 'copy', '-segment_time', '1200', '-f', 'segment', '-reset_timestamps', '1', pattern, '-y'], capture_output=True, creationflags=subprocess.CREATE_NO_WINDOW if hasattr(subprocess, 'CREATE_NO_WINDOW') else 0)
    
    parts = sorted([os.path.join(tmp_dir, f) for f in os.listdir(tmp_dir) if f.endswith('.mp4')])
    texts = []
    for i, part in enumerate(parts):
        send_progress('변환 중 (' + str(i+1) + '/' + str(len(parts)) + ')...', 60 + int(30 * i / len(parts)))
        ok, result = transcribe(api_key, part)
        if not ok:
            return False, result
        texts.append(result)
    
    return True, '\n\n'.join(texts)

def main():
    while True:
        msg = read_message()
        if msg is None:
            break
        
        action = msg.get('action')
        
        if action == 'ping':
            send_message({'type': 'pong', 'ok': True})
        
        elif action == 'transcribe':
            m3u8_url = msg.get('url')
            api_key = msg.get('apiKey')
            title = msg.get('title', 'lecture')
            
            # FFmpeg 찾기
            ffmpeg = find_ffmpeg()
            if not ffmpeg:
                send_message({'type': 'error', 'message': 'FFmpeg가 없어요. PowerShell에서 "winget install ffmpeg" 실행 후 크롬을 재시작해주세요.'})
                continue
            
            tmp_dir = tempfile.mkdtemp()
            output_path = os.path.join(tmp_dir, title + '.mp4')
            
            ok, err = run_ffmpeg(ffmpeg, m3u8_url, output_path)
            if not ok:
                send_message({'type': 'error', 'message': err})
                continue
            
            send_progress('다운로드 완료! 텍스트 변환 중...', 50)
            
            ok, result = transcribe(api_key, output_path)
            if not ok:
                send_message({'type': 'error', 'message': result})
                continue
            
            send_progress('완료!', 100)
            send_message({'type': 'result', 'text': result, 'ok': True})
            
            try:
                os.remove(output_path)
                os.rmdir(tmp_dir)
            except:
                pass

if __name__ == '__main__':
    main()
