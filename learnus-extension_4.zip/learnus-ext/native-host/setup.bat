@echo off
chcp 65001 >nul
echo.
echo ========================================
echo   런어스 스크립트 추출기 설치
echo ========================================
echo.

:: Python 확인
python --version >nul 2>&1
if errorlevel 1 (
    echo [오류] Python이 설치되어 있지 않아요.
    echo https://www.python.org 에서 Python 3.x 설치 후 다시 실행해주세요.
    pause
    exit /b 1
)
echo [OK] Python 확인됨

:: FFmpeg 확인
ffmpeg -version >nul 2>&1
if errorlevel 1 (
    echo [설치 중] FFmpeg 설치 중... (시간이 걸릴 수 있어요)
    winget install --id Gyan.FFmpeg --silent --accept-package-agreements --accept-source-agreements
    if errorlevel 1 (
        echo [경고] FFmpeg 자동 설치 실패했어요.
        echo cmd에서 수동 설치: winget install ffmpeg
    ) else (
        echo [OK] FFmpeg 설치 완료
    )
) else (
    echo [OK] FFmpeg 확인됨
)

:: 경로 설정
set SCRIPT_DIR=%~dp0
set HOST_PATH=%SCRIPT_DIR%host.py

:: 확장 ID 입력 받기
echo.
echo chrome://extensions 에서 확장 프로그램 ID를 확인해주세요.
echo (런어스 스크립트 추출기 아래에 표시된 영문+숫자 조합)
echo.
set /p EXT_ID=확장 프로그램 ID 입력: 

:: Native Messaging manifest 생성
set MANIFEST_PATH=%SCRIPT_DIR%com.learnus.script.json
(
echo {
echo   "name": "com.learnus.script",
echo   "description": "Learnus Script Extractor Native Host",
echo   "path": "%HOST_PATH:\=\\%",
echo   "type": "stdio",
echo   "allowed_origins": [
echo     "chrome-extension://%EXT_ID%/"
echo   ]
echo }
) > "%MANIFEST_PATH%"

:: 레지스트리 등록
reg add "HKCU\Software\Google\Chrome\NativeMessagingHosts\com.learnus.script" /ve /t REG_SZ /d "%MANIFEST_PATH%" /f >nul
if errorlevel 1 (
    echo [오류] 레지스트리 등록 실패했어요.
    pause
    exit /b 1
)

echo.
echo ========================================
echo   설치 완료!
echo   크롬을 완전히 종료 후 다시 열어주세요.
echo ========================================
echo.
pause
