$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$hostPath = Join-Path $scriptDir "host.py"
$extId = Read-Host "Extension ID"
$manifestPath = Join-Path $scriptDir "manifest.json"
$manifest = '{"name":"com.learnus.script","description":"Learnus Script Extractor","path":"' + $hostPath.Replace('\','\\') + '","type":"stdio","allowed_origins":["chrome-extension://' + $extId + '/"]}'
$manifest | Out-File -FilePath $manifestPath -Encoding utf8
New-Item -Path "HKCU:\Software\Google\Chrome\NativeMessagingHosts\com.learnus.script" -Force | Out-Null
Set-ItemProperty -Path "HKCU:\Software\Google\Chrome\NativeMessagingHosts\com.learnus.script" -Name "(Default)" -Value $manifestPath
Write-Host "Done! Restart Chrome."
Read-Host "Press Enter"
