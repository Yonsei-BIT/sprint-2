var state = { url: null, title: '강의', duration: 0 };
var NATIVE_HOST = 'com.learnus.script';

function show(id) {
  ['s1','s1b','s2','s3','s4','s5','s-setup'].forEach(function(i) {
    document.getElementById(i).classList.remove('on');
  });
  document.getElementById(id).classList.add('on');
}

function checkNow() {
  var btn = document.getElementById('btn-check');
  chrome.runtime.sendMessage({ type: 'GET_ALL_CACHED' }, function(res) {
    if (res && res.url) {
      state.url = res.url;
      state.title = res.title || '강의';
      showStep2();
    } else {
      if (btn) btn.textContent = '아직 감지 안됨 — 영상 재생 후 다시 클릭';
    }
  });
}

function showStep2() {
  document.getElementById('url-display').textContent = state.url;
  document.getElementById('lec-name').value = state.title;
  if (state.duration) document.getElementById('lec-dur').value = state.duration;
  // 저장된 API 키 로드
  chrome.storage.local.get('apiKey', function(data) {
    if (data.apiKey) document.getElementById('api-key').value = data.apiKey;
  });
  show('s2');
}

function startTranscribe() {
  var name = document.getElementById('lec-name').value.trim() || state.title;
  var dur = parseInt(document.getElementById('lec-dur').value) || 0;
  var apiKey = document.getElementById('api-key').value.trim();

  if (!apiKey || !apiKey.startsWith('sk-')) {
    document.getElementById('api-key').style.borderColor = '#f87171';
    return;
  }

  // API 키 저장
  chrome.storage.local.set({ apiKey: apiKey });

  show('s3');
  setProgress('준비 중...', 5);

  // Native Host 연결
  var port = chrome.runtime.connectNative(NATIVE_HOST);

  port.onMessage.addListener(function(msg) {
    if (msg.type === 'progress') {
      setProgress(msg.message, msg.percent || 0);
    } else if (msg.type === 'result') {
      show('s4');
      document.getElementById('result-text').textContent = msg.text;
    } else if (msg.type === 'error') {
      show('s5');
      document.getElementById('err-msg').textContent = msg.message;
    } else if (msg.type === 'pong') {
      // 연결 확인됨, 변환 시작
      port.postMessage({
        action: 'transcribe',
        url: state.url,
        apiKey: apiKey,
        title: name.replace(/[^\w\uAC00-\uD7A3]/g, '_'),
        duration: dur
      });
    }
  });

  port.onDisconnect.addListener(function() {
    if (chrome.runtime.lastError) {
      show('s-setup');
    }
  });

  // ping으로 연결 확인
  port.postMessage({ action: 'ping' });
}

function setProgress(msg, percent) {
  document.getElementById('prog-msg').textContent = msg;
  document.getElementById('prog-bar').style.width = percent + '%';
}

document.addEventListener('DOMContentLoaded', function() {
  document.getElementById('btn-check').addEventListener('click', checkNow);
  document.getElementById('btn-manual').addEventListener('click', function() { show('s1b'); });
  document.getElementById('btn-submit-manual').addEventListener('click', function() {
    var url = document.getElementById('manual-url').value.trim();
    if (url.indexOf('m3u8') !== -1) {
      state.url = url;
      showStep2();
    } else {
      document.getElementById('manual-url').style.borderColor = '#f87171';
    }
  });
  document.getElementById('btn-save-key').addEventListener('click', function() {
    var key = document.getElementById('api-key').value.trim();
    if (key) {
      chrome.storage.local.set({ apiKey: key });
      this.textContent = '저장됨 ✓';
      setTimeout(function() { document.getElementById('btn-save-key').textContent = '저장'; }, 1500);
    }
  });
  document.getElementById('btn-start').addEventListener('click', startTranscribe);
  document.getElementById('btn-back-s1').addEventListener('click', function() { show('s1'); });
  document.getElementById('btn-retry').addEventListener('click', function() { show('s2'); });
  document.getElementById('btn-retry-setup').addEventListener('click', function() { show('s1'); checkNow(); });
  document.getElementById('btn-restart').addEventListener('click', function() { show('s1'); checkNow(); });
  document.getElementById('btn-copy-result').addEventListener('click', function() {
    var text = document.getElementById('result-text').textContent;
    var btn = this;
    navigator.clipboard.writeText(text).then(function() {
      btn.textContent = '복사됨 ✓';
      setTimeout(function() { btn.textContent = '텍스트 복사'; }, 1500);
    });
  });

  setTimeout(checkNow, 300);
});
